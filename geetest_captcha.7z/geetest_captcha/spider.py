#!/usr/bin/env python 
# -*- coding:utf-8 -*- 
# @Author: HuangChen 
# @Date: 2019/7/25 15:24
# @Last Modified by:   HuangChen 
# @Last Modified time: 2019/7/25 15:24

import uuid
import time

from selenium import webdriver
from zhimaip import getdailione
from selenium.common.exceptions import ElementClickInterceptedException
from selenium.common.exceptions import WebDriverException

def save_img(driver):
    time.sleep(1)
    js = '''
        document.getElementsByClassName('geetest_big_item')[0].style.height = '100px';
        document.getElementsByClassName('geetest_item_img')[0].style.height = 'auto';
    '''
    driver.execute_script(js)

    time.sleep(1)

    img_ele = driver.find_element_by_css_selector('.geetest_item_img')
    try:
        img_ele.screenshot('captcha/{}.png'.format(uuid.uuid1()))
    except:
        print('保存失败')

ip, expire_time = getdailione(3)

chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument("--proxy-server={}".format(ip))
driver = webdriver.Chrome('chromedriver.exe', chrome_options=chrome_options)
driver.maximize_window()

driver.get('https://www.geetest.com/Sensebot')
click_pick = driver.find_element_by_css_selector('.box-left li:last-child')
click_pick.click()

time.sleep(3)

driver.find_element_by_css_selector('.geetest_radar_tip').click()

while True:
    try:
        save_img(driver)
        driver.find_element_by_css_selector('.geetest_refresh').click()
        time.sleep(3)
    except:
        time.sleep(1)
        driver.find_element_by_css_selector('.geetest_radar_tip').click()
        time.sleep(5)